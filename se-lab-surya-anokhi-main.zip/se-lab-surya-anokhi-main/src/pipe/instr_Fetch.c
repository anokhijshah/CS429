/**************************************************************************
 * C S 429 system emulator
 * 
 * instr_Fetch.c - Fetch stage of instruction processing pipeline.
 **************************************************************************/ 

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <assert.h>
#include "err_handler.h"
#include "instr.h"
#include "instr_pipeline.h"
#include "machine.h"
#include "hw_elts.h"

extern machine_t guest;
extern mem_status_t dmem_status;

extern uint64_t F_PC;

/*
 * Select PC logic.
 * STUDENT TO-DO:
 * Write the next PC to *current_PC.
 */

static comb_logic_t 
select_PC(uint64_t pred_PC,                                     // The predicted PC
          opcode_t D_opcode, uint64_t val_a,                    // Possible correction from RET
          opcode_t M_opcode, bool M_cond_val, uint64_t seq_succ,// Possible correction from B.cond
          uint64_t *current_PC) {
    /* 
     * Students: Please leave this code
     * at the top of this function. 
     * You may modify below it. 
     */
    if (D_opcode == OP_RET && val_a == RET_FROM_MAIN_ADDR) {
        *current_PC = 0; // PC can't be 0 normally.
        return;
    }
    // Case 1: Mispredicted branch correction
    else if (!M_cond_val && M_opcode == OP_B_COND) {
        *current_PC = seq_succ;
    }
    // Case 2: Handling a RET instruction
    else if (D_opcode == OP_RET) {
        *current_PC = val_a;
    }
    // Case 3: Base case
    else {
        *current_PC = pred_PC;
    }
    return;
}

/*
 * Predict PC logic. Conditional branches are predicted taken.
 * STUDENT TO-DO:
 * Write the predicted next PC to *predicted_PC
 * and the next sequential pc to *seq_succ.
 */

static comb_logic_t 
predict_PC(uint64_t current_PC, uint32_t insnbits, opcode_t op, 
           uint64_t *predicted_PC, uint64_t *seq_succ) {
    /* 
     * Students: Please leave this code
     * at the top of this function. 
     * You may modify below it. 
     */
    if (!current_PC) {
        return; // We use this to generate a halt instruction.
    }

    // Case 1: Unconditional branch
    if (op == OP_B || op == OP_BL) {
        // Extract the branch offset
        int64_t offset = bitfield_s64(insnbits, 0, 26) * 4;

        // Calculate the branch target address and sequential successor
        *predicted_PC = current_PC + offset;
        *seq_succ = current_PC + 4;
    }
    // Case 2: Conditional branch
    else if (op == OP_B_COND) {
        // Extract the branch offset
        int64_t offset = bitfield_s64(insnbits, 5, 19);

        // Calculate the branch target address and sequential successor
        *predicted_PC = current_PC + (offset << 2);
        *seq_succ = current_PC + 4;
    }
    // Case 3: ADRP
    else if (op == OP_ADRP) {
        *predicted_PC = current_PC + 4;
        *seq_succ = current_PC & (~0xFFFUL);
    } 
    // Case 4: Base case
    else {
        *predicted_PC = current_PC + 4;
        *seq_succ = current_PC + 4;
    }
    return;
}

static
void fix_instr_aliases(uint32_t insnbits, opcode_t *op) {
    // Check if the alias is OP_SUBS_RR (a subtraction with flags) and set the opcode accordingly.
    if (*op == OP_SUBS_RR && ((insnbits) & 0x1F) == 0x1F) {
        // get first 5 bits and if it is 31 then set to it
        *op = OP_CMP_RR; // Set the opcode to conditional branch.
    } 

    // Check if the alias is OP_ANDS_RR (bitwise AND with flags) and set the opcode accordingly.
    else if (*op == OP_ANDS_RR && ((insnbits) & 0x1F) == 0x1F) {
        // get first 5 bits and if it is 31 then set to it
        *op = OP_TST_RR; // Set the opcode to a bitwise test instruction.
    }
    else if (*op == OP_UBFM) {
        if (bitfield_u32(insnbits, 10, 6) == 63) {
            *op = OP_LSR;
        } else if (bitfield_u32(insnbits, 10, 6) + 1 == bitfield_u32(insnbits, 16, 6)) {
            *op = OP_LSL;
        }
    }
    else {
        *op = *op;
    }
    return;
}

/*
 * Fetch stage logic.
 * STUDENT TO-DO:
 * Implement the fetch stage.
 * 
 * Use in as the input pipeline register,
 * and update the out pipeline register as output.
 * Additionally, update F_PC for the next
 * cycle's predicted PC.
 * 
 * You will also need the following helper functions:
 * select_pc, predict_pc, and imem.
 */
comb_logic_t fetch_instr(f_instr_impl_t *in, d_instr_impl_t *out) {
    bool imem_err = 0;
    uint64_t current_PC;
    select_PC(in->pred_PC, X_out->op, X_out->val_a, M_out->op, M_out->cond_holds, M_out->seq_succ_PC, &current_PC);    
    /* 
     * Students: This case is for generating HLT instructions
     * to stop the pipeline. Only write your code in the **else** case. 
     */
    if (!current_PC || F_in->status == STAT_HLT) {
        out->insnbits = 0xD4400000U;
        out->op = OP_HLT;
        out->print_op = OP_HLT;
        imem_err = false;
    }
    else {
        // Get the insnbits for the current instruction
        // Fetch the instruction from memory using the imem function
        imem(current_PC, &out->insnbits, &imem_err);
        
        // Decode those bits to get the opcode
        // Extract the 11-bit field at bits 21-10 from the instruction bits.
        uint32_t op_field = bitfield_u32(out->insnbits, 21, 11);

        // Look up the corresponding opcode for the given op_field.
        out->op = itable[op_field];

        // Decode the instruction to determine the opcode, considering alias instructions
        fix_instr_aliases(out->insnbits, &out->op);
        out->print_op = out->op;            

        // Predict the next PC and sequential successor PC
        predict_PC(current_PC, out->insnbits, out->op, &F_PC, &out->seq_succ_PC);
    }
    
    // We do not recommend modifying the below code.
    if (imem_err || out->op == OP_ERROR) {
        in->status = STAT_INS;
        F_in->status = in->status;
    } else if (out->op == OP_HLT) {
        in->status = STAT_HLT;
        F_in->status = in->status;
    } else {
        in->status = STAT_AOK;
    }
    out->status = in->status;
    return;
}