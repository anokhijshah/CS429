#include "umalloc.h"
#include "csbrk.h"
#include <stdio.h>
#include <assert.h>
#include "ansicolors.h"

const char author[] = ANSI_BOLD ANSI_COLOR_RED "Anokhi Shah ajs7877" ANSI_RESET;

/*
 * The following helpers can be used to interact with the memory_block_t
 * struct, they can be adjusted as necessary.
 */

// A sample pointer to the start of the free list.
memory_block_t *free_head;

/*
 * is_allocated - returns true if a block is marked as allocated.
 */
bool is_allocated(memory_block_t *block) {
    assert(block != NULL);
    return block->block_size_alloc & 0x1;
}

/*
 * allocate - marks a block as allocated.
 */
void allocate(memory_block_t *block) {
    assert(block != NULL);
    block->block_size_alloc |= 0x1;
}

/*
 * deallocate - marks a block as unallocated.
 */
void deallocate(memory_block_t *block) {
    assert(block != NULL);
    block->block_size_alloc &= ~0x1;
}

/*
 * get_size - gets the size of the block.
 */
size_t get_size(memory_block_t *block) {
    assert(block != NULL);
    return block->block_size_alloc & ~(ALIGNMENT-1);
}

/*
 * get_next - gets the next block.
 */
memory_block_t *get_next(memory_block_t *block) {
    assert(block != NULL);
    return block->next;
}

/*
 * put_block - puts a block struct into memory at the specified address.
 * Initializes the size and allocated fields, along with NUlling out the next 
 * field.
 */
void put_block(memory_block_t *block, size_t size, bool alloc) {
    assert(block != NULL);
    assert(size % ALIGNMENT == 0);
    assert(alloc >> 1 == 0);
    block->block_size_alloc = size | alloc;
    block->next = NULL;
}

/*
 * get_payload - gets the payload of the block.
 */
void *get_payload(memory_block_t *block) {
    assert(block != NULL);
    return (void*)(block + 1);
}

/*
 * get_block - given a payload, returns the block.
 */
memory_block_t *get_block(void *payload) {
    assert(payload != NULL);
    return ((memory_block_t *)payload) - 1;
}

/*
 * The following are helper functions that can be implemented to assist in your
 * design, but they are not required. 
 */

/*
 * find - finds a free block that can satisfy the umalloc request.
 */
memory_block_t *find(size_t size) {
    // Iterate through the free list to find the first block that fits
    memory_block_t *current = free_head;
    while (current != NULL) {
        if (!is_allocated(current) && get_size(current) >= size) {
            if (get_size(current) > size) {
                // If the block is larger than needed, split it
                return split(current, size);
            } 
            else {
                return current;
            }
        }
        current = current->next;
    }

    return NULL;
}

/*
 * extend - extends the heap if more memory is required.
 */
memory_block_t *extend(size_t size) {
    // Allocate memory using csbrk and initialize it as an unallocated block
    memory_block_t *new_block = csbrk(size);

    if (free_head != NULL) {
        // Find the last block in the free list
        memory_block_t *last_free_block = free_head;
        while (last_free_block->next != NULL) {
            last_free_block = last_free_block->next;
        }
        // Add the allocated block to the end of the free list
        last_free_block->next = new_block;
    }
    put_block(new_block, size, false);

    return new_block;
}

/*
 * split - splits a given block in parts, one allocated, one free.
 */
memory_block_t *split(memory_block_t *free_block, size_t size) {
    // Calculate the size of the remaining free block
    size_t remaining_size = get_size(free_block) - size;

    // Calculate the address of the allocated block
    memory_block_t *allocated_block = free_block + remaining_size / sizeof(memory_block_t);

    free_block->block_size_alloc = remaining_size;

    if (allocated_block == free_block) {
        if (free_head != allocated_block) {
            // Traverse the free list to find and remove the free block
            memory_block_t *current = free_head;
            memory_block_t *previous = NULL;

            while (current != NULL && current != free_block) {
                previous = current;
                current = get_next(current);
            }

            if (current != NULL) {
                previous->next = get_next(free_block);
            }
        } 
        else {
            free_head = get_next(free_head);
        }
    }

    put_block(allocated_block, size, true);

    return allocated_block;
}

/*
 * coalesce - coalesces a free memory block with neighbors.
 */
memory_block_t *coalesce(memory_block_t *block) {
    size_t block_end = (size_t)block + get_size(block);

    // Find the block just before the given block in the free list
    memory_block_t *prev_block = NULL;
    memory_block_t *current_block = free_head;

    while (current_block && (size_t)current_block < (size_t)block) {
        prev_block = current_block;
        current_block = current_block->next;
    }

    // Check if the next block is adjacent to the given block and free
    if (current_block && (size_t)current_block == block_end && !is_allocated(current_block)) {
        block->block_size_alloc += get_size(current_block);
        block->next = current_block->next;
    }

    // Check if the previous block is adjacent to the given block and free
    if (prev_block && (size_t)block == (size_t)prev_block + get_size(prev_block) && !is_allocated(prev_block)) {
        prev_block->block_size_alloc += get_size(block);
        prev_block->next = block->next;
        return prev_block;
    }

    // If no coalescing occurred, mark the block as free
    block->block_size_alloc &= ~0x1;

    return block;
}

/*
 * uinit - Used initialize metadata required to manage the heap
 * along with allocating initial memory.
 */
int uinit() {
    void *ptr = csbrk(PAGESIZE * 3);
    free_head = (memory_block_t *)ptr;
    put_block(free_head, PAGESIZE, false);
    return 0;
}

/*
 * umalloc -  allocates size bytes and returns a pointer to the allocated memory.
 */
void *umalloc(size_t size) {
    size_t total_size = size + sizeof(memory_block_t);

    // Ensure that total_size is a multiple of ALIGNMENT
    total_size = ((total_size + ALIGNMENT - 1) / ALIGNMENT) * ALIGNMENT;

    memory_block_t *allocated_block = find(total_size);

    if (allocated_block == NULL) {
        allocated_block = extend(total_size);
    }

    allocate(allocated_block);

    // Remove the allocated block from the free list
    memory_block_t **prev_next_ptr = &free_head;
    while (*prev_next_ptr != NULL && *prev_next_ptr != allocated_block) {
        prev_next_ptr = &(*prev_next_ptr)->next;
    }

    if (*prev_next_ptr != NULL) {
        *prev_next_ptr = allocated_block->next;
    }

    return get_payload(allocated_block);
}


/*
 * ufree -  frees the memory space pointed to by ptr, which must have been called
 * by a previous call to malloc.
 */
void ufree(void *ptr) {
    memory_block_t *block_to_free = get_block(ptr);
    deallocate(block_to_free);

    memory_block_t *previous = NULL;
    memory_block_t *current = free_head;

    // Find the correct spot based on memory address
    while (current != NULL && current < block_to_free) {
        previous = current;
        current = current->next;
    }

    if (previous == NULL) {
        // Insert at the beginning of the free list
        block_to_free->next = free_head;
        free_head = block_to_free;
    } 
    else {
        // Insert after the 'previous' block
        block_to_free->next = previous->next;
        previous->next = block_to_free;
    }

    coalesce(block_to_free);
}
