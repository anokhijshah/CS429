#!/bin/bash
python3 -m pip install tabulate --user