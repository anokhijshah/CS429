#include "umalloc.h"
int check_heap();